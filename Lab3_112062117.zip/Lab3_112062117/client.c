#include "header.h"
#define PORT 45525

/*
 * @description
 * 1. Create a socket and connect to server.
 *    (server's IP address = "127.0.0.1")
 *    (server's Port number = 45525)
 * 2. Receive message: "Hi, I'm server {Your_student_ID}..." from server and print it out.
 *    (The message you sent from server)
 * 3. Continuously receive data from server and send back ACK.
*/
int loss = -1;

int main(int argc, char *argv[]) {
    int socket_fd;
    struct sockaddr_in server_addr;

    // Create TCP socket.
    socket_fd = socket(AF_INET, SOCK_STREAM, 0);
    // Set up server's address.
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    //將字串格式的 IP 位址（例如 "127.0.0.1"）轉換成二進位格式，並儲存在 server_addr.sin_addr 中。
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);
    // Connect to server's socket.
    if (connect(socket_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        return -1;
    }
    // Receive message: "Hi, I'm server {Your_student_ID}..." from server and print it out.
    char buffer[1024] = {0};
    if(recv(socket_fd, buffer, sizeof(buffer), 0) <= 0) {
        perror("Receive failed");
        close(socket_fd);
        return -1;
    }
    printf("Received from server: %s\n", buffer);
    // Receive data and send ACK continuously.

    int rec[1000] = {-1};
    int rec_num = 0;
    int index = 0;
    int new = 0;
    while (1) {
        Segment segment, ack_segment;
        // Receive data from server.
        int bytes = recv(socket_fd, &segment, sizeof(segment), 0);
        if (bytes <= 0) {
            break; // Connection closed or error occurred.
        }
        if(!segment.loss && segment.seq_num + 1> new) {
            new = segment.seq_num + 1;
        }
        
        if(segment.loss) {
            printf("Loss: seq_num=%d\n", segment.seq_num);
            rec[rec_num++] = segment.seq_num;
            if(loss == -1) {
                ack_segment.ack_num = segment.seq_num ; // ACK for the same sequence number.
                send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
                loss = segment.seq_num;
                continue;
            } else {
                ack_segment.ack_num = loss; // ACK for the same sequence number.
                send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
            }


        } else if (loss != -1){
            //printf("Loss:%d seq_num=%d\n", loss, segment.seq_num);
            if(loss == segment.seq_num ) {
                printf("Received: seq_num=%d\n", segment.seq_num);
                
                while(1){
                    index += 1;
                    if(index == rec_num || rec[index] > loss){
                        break;
                    }
                }
                if(index == rec_num ){
                    index = 0 ;
                    rec_num = 0;
                    loss = -1;
                    ack_segment.ack_num = new; // ACK for the next expected sequence number.
                    ack_segment.loss = false; // No loss for ACK.
                    send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
                    continue;
                }
                loss = rec[index];
                //printf("Loosss: seq_num=%d  %d %d\n", loss, rec_num, index);
                ack_segment.ack_num = loss;
                ack_segment.loss = false; // No loss for ACK.
                send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
            } else {
                printf("Received: seq_num=%d\n", segment.seq_num);
                ack_segment.ack_num = loss ; // ACK for the same sequence number.
                send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
            }


        } else {
            printf("Received: seq_num=%d\n", segment.seq_num);
            ack_segment.ack_num = new > segment.seq_num + 1 ? new : segment.seq_num + 1; // ACK for the next expected sequence number.
            ack_segment.loss = false; // No loss for ACK.
            send(socket_fd, &ack_segment, sizeof(ack_segment), 0);
        }
        
        
        // Simulate ACK sending.
        

        
    }
    // Close the socket.
    printf("Close socket\n");
    close(socket_fd);
    return 0;
}