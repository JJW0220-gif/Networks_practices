#include "header.h"
#define PORT 45525

/*
 * @description
 * Write your server's send function here.
 * 1. Send cwnd number of data segments starting with the correct sequence number.
 * 2. Simulate packet loss.
 * 
 * @param
 * You can increase or decrease parameters by yourself.
 * Some useful information can be used either as global varaible or passed as parameters to functions:
 * 1. client_fd: The socket descriptor used for sending/receiving data  
 *               with a client that has connected to server.
 * 2. last_acked: previous acknowledge packets
 * 3. cwnd: congestion window size
*/
int rec = -1;
int idx = 0;
int ppp = 3;
//int res_num = 0;
//int resend [100] = {-1}; 
void server_send(int client_fd, int cwnd) {
    int plus = cwnd;
    for (int i = 0; i < cwnd; ++i) {

        Segment seg;
        seg.seq_num = idx + i;
        seg.loss = false;
        
        if (packet_loss()) {
            seg.loss = true;
            printf("Send: seq_num = %d\n", seg.seq_num);
        } else {
            printf("Send: seq_num = %d\n", seg.seq_num);
            
        }
        
        /*if (seg.seq_num == 26 ||seg.seq_num == 28 || seg.seq_num == 40 ) {
            if(ppp % 3 == 0){
                seg.loss = true;
                printf("loss: seq_num = %d\n", seg.seq_num);
                
            } else {
                //ppp += 1;
                seg.loss = false;
                ppp += 1;
                printf("Send: seq_num = %d\n", seg.seq_num);
            }
            
        } else {
            printf("Send: seq_num = %d\n", seg.seq_num);
            
        }*/
        send(client_fd, &seg, sizeof(seg), 0);
        
    }


    


}
/*
 * @description
 * Write your server's receive function here.
 * We don't need to consider time-out in this lab. Loss will only occur when packet_loss() == true.
 * 1. Receive ACKs from client.
 * 2. Detect if 3 duplicate ACK occurs.
 * 3. Update cwnd and ssthresh.
 * 
 * @param
 * You can increase or decrease parameters by yourself.
 * Some useful information can be used either as global varaible or passed as parameters to functions:
 * 1. client_fd: The socket descriptor used for sending/receiving data  
 *               with a client that has connected to server.
 * 2. last_acked: previous acknowledge packets
 * 3. ssthresh: slow start threshold
 * 4. cwnd: congestion window size
*/
void server_receive(int client_fd, int *last_acked, int *cwnd, int *ssthresh) {
    Segment ack;
    int duplicate_ack_count = 0;

    for (int i = 0; i < *cwnd; i++) {
        if (recv(client_fd, &ack, sizeof(Segment), 0) <= 0) break;

        printf("ACK: ack_num = %d\n", ack.ack_num);

        //printf("%d %d\n", ack.ack_num, idx +1 );
        if(ack.ack_num  > idx+ 1|| rec != -1)
            idx = ack.ack_num;
        else idx = idx + 1;
        
        //printf("idx: %d", idx);

        if (*last_acked != -1 && ack.ack_num == *last_acked) {
            duplicate_ack_count++;
        } else {
            duplicate_ack_count = 1;
            *last_acked = ack.ack_num;
        }

        if (duplicate_ack_count == 3) {
            rec = 1;
            printf("3 duplicate ACKs : ACK_num = %d, ssthresh = %d\n", ack.ack_num, *ssthresh);
            idx = ack.ack_num;
        }
    }



    if(rec != -1) {
        *ssthresh = *cwnd / 2;
        *cwnd = 1;
        rec = -1;
        ppp += 1;
        printf("State: slow start (cwnd = %d, ssthresh = %d)\n", *cwnd, *ssthresh);
    } else if (*cwnd < *ssthresh) {
        if(*cwnd * 2 < *ssthresh )
            (*cwnd) *= 2;
        else 
            *cwnd = *ssthresh;
        
        printf("State: slow start (cwnd = %d, ssthresh = %d)\n", *cwnd, *ssthresh);
    } else {
        *cwnd += 1 ;
        printf("State: congestion avoidance (cwnd = %d, ssthresh = %d)\n", *cwnd, *ssthresh);
    }
}

/*
 * @description
 * 1. Create a TCP socket bind to port 45525.
 * 2. Listen the TCP socket.
 * 3. Accept the connect and get the client socket file descriptor (client_fd).
 * 4. Send message: "Hi, I'm server {Your_student_ID}" to client.
 * 5. Complete the functions: server_send() and server_receive()
 * 6. Start data transmission with simulating congestion control.
 *
 * To be simple, we receive ACKs only after all cwnd number of data segments are sent, 
 * so we cannot react to 3-duplicate ACKs immediately. This is ok for this lab.
*/
int main(int argc, char* argv[]) {
    srand(time(NULL));
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    int addr_len = sizeof(client_addr);

    // Create TCP socket.
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        return -1;
    }
    // Set up server's address.
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = INADDR_ANY; // Bind to all interfaces.

    // Bind socket to the address.
    //bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_fd);
        return -1;
    }
    // Listening the socket.
    if(listen(server_fd, 5)<0) {
        perror("Listen failed");
        close(server_fd);
        return -1;
    }
    
    // Accept the connect request.
    client_fd = accept(server_fd, (struct sockaddr *)&client_addr, (socklen_t*)&addr_len);
    if (client_fd < 0) {
        perror("Accept failed");
        close(server_fd);
        return -1;
    }
    printf("New connection\n");
    
    // Send message: "Hi, I'm server {Your_student_ID}" to client.
    char greet[] = "Hi, I'm server 112062117\n";
    send(client_fd, greet, sizeof(greet), 0);
    usleep(500000); 

    // Start congestion control.
    int ROUND = 10, cwnd = 1, ssthresh = 8, last_acked = -1, next_seq_num = 0;
    FILE *fp = fopen("cwnd.txt", "w");
    if (fp == NULL) {
        perror("Failed to open cwnd.txt");
        return 1;
    }
    printf("State: slow start (cwnd = %d, ssthresh = %d)\n", cwnd, ssthresh);
    fprintf(fp, "%d\n", cwnd);
    fflush(fp);
    idx = 0;
    while (ROUND--) {
        //printf("\n[ROUND %d] cwnd = %d, ssthresh = %d\n", 10 - ROUND, cwnd, ssthresh);
        server_send(client_fd, cwnd);
        usleep(500000);
        server_receive(client_fd, &last_acked, &cwnd, &ssthresh);
        fprintf(fp, "%d\n", cwnd);
        fflush(fp);
    }

    fclose(fp);

    // Close the socket.
    printf("Close client socket\n");
    close(client_fd);
    printf("Close server socket\n");
    close(server_fd);
    return 0;
}