#include "header.h"
#define PORT 45525
#define BUFFER_SIZE 1024
// TCP pseudo-header
/*
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                         Source Address                        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                      Destination Address                      |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|      Zero     |    Protocol   |           TCP Length          |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

// TCP header (without options)
/*
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|          Source Port          |       Destination Port        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                        Sequence Number                        |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|                     Acknowledgment Number                     |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
|  Data |           |U|A|P|R|S|F|                               |
| Offset|  Reserved |R|C|S|S|Y|I|          Window Size          |
|       |           |G|K|H|T|N|N|                               |
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
+            Checksum           |      Urgent Data Pointer      +
+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+-+
*/

/*
 * @description
 * 1. Create pseudo-header
 * 2. Create header without checksum
 * 3. Calculate the checksum
 * 4. Fill in the checksum field in the header
 * 
 * @param
 * s: The segment sent from server
*/
// Assume that the TCP segment is a pure ACK (no payload), that is TCP_length == TCP_header_length.
// Note that TCP_header_length is a multiple of 4 bytes.
// Hint: memcpy(), inet_addr(), htons(), htonl(), uint16_t, uint32_t, bitwise operation
// Fill pseudo-header with source, destination, protocol, and TCP length
void fillPseudoHeader(Segment* seg) {

    memcpy(seg->pseudoheader, (const void *)&(uint32_t){inet_addr(seg->l3info.SourceIpv4)}, 4);
    memcpy(seg->pseudoheader + 4, (const void *)&(uint32_t){inet_addr(seg->l3info.DestIpv4)}, 4);
    seg->pseudoheader[8] = 0;
    seg->pseudoheader[9] = (uint8_t)seg->l3info.protocol;
    memcpy(seg->pseudoheader + 10, (const void *)&(uint16_t){htons(20)}, 2);
}

// Fill TCP header fields, leaving checksum as zero
void fillTcpHeader(Segment* seg) {

    memset(seg->header, 0, 20);

    memcpy(seg->header, (const void *)&(uint16_t){htons(seg->l4info.SourcePort)}, 2);
    memcpy(seg->header + 2, (const void *)&(uint16_t){htons(seg->l4info.DestPort)}, 2);
    memcpy(seg->header + 4, (const void *)&(uint32_t){htonl(seg->l4info.SeqNum)}, 4);
    memcpy(seg->header + 8, (const void *)&(uint32_t){htonl(seg->l4info.AckNum)}, 4);

    seg->header[12] = (seg->l4info.HeaderLen << 4);
    seg->header[13] = (uint8_t)seg->l4info.Flag;

    memcpy(seg->header + 14, (const void *)&(uint16_t){htons(seg->l4info.WindowSize)}, 2);
    seg->header[18] = 0;
    seg->header[19] = 0;
}

// Compute checksum for a byte array
uint16_t computeChecksum(uint8_t* data, int length) {
    uint32_t sum = 0;
    for (int i = 0; i < length; i += 2) {
        uint16_t word = (data[i] << 8) + data[i + 1];
        sum += word;
        if (sum > 0xFFFF) {
            sum = (sum & 0xFFFF) + 1;
        }
    }
    return ~sum;
}

void createHeader(Segment* seg) {
    fillPseudoHeader(seg);
    fillTcpHeader(seg);

    uint8_t combined[32];
    memcpy(combined, seg->pseudoheader, 12);
    memcpy(combined + 12, seg->header, 20);

    uint16_t checksum = computeChecksum(combined, 32);
    uint16_t netChecksum = htons(checksum);
    memcpy(seg->header + 16, &netChecksum, 2);
}


/*
 * @description
 * In this function, You need to implement the client side
 * that sends messages to and receives messages from the server.
 *
 *         Receive the message: "Enter a command (data / time)..."
 * Server -----------------------------------------------------------> Client
 * 
 *         Send the message: "data" or "time" or {invalid command}
 * Server <----------------------------------------------------------- Client
 * 
 *         data: 1. Print "Receive DATA from server..."
 *               2. Receive Segment from server
 *               3. printSegment() -> createHeader() -> printHeader()
 *               4. Close the socket
 *         time: 1. Print "Receive TIME from server..."
 *               2. Receive time string from server and print it out
 *               3. Close the socket
 *         {invalid command}: Do nothing
 * Server -----------------------------------------------------------> Client
 *
 * @param
 * socket_fd: The socket file descriptor used for sending/receiving data
 *            with a client that has connected to server.
 * s        : The segment sent from server
*/
void receiveData(int socket_fd, Segment* s) {

    char buffer[BUFFER_SIZE];
    int bytes = recv(socket_fd, buffer, sizeof(buffer) - 1, 0);
    buffer[bytes] = '\0';
    printf("server: %s\n", buffer);

    while(1){
    // 輸入指令
        char command[100];
        fgets(command, sizeof(command), stdin);
        command[strlen(command) - 1] = '\0';     //找出 \n 在哪個位置，然後把它換成字串結束符 \0
        send(socket_fd, command, strlen(command), 0);
        if (strcmp(command, "data") == 0) {
            printf("Receive DATA from server...\n");
            printf("\n");
            recv(socket_fd, s, sizeof(Segment), 0);
            printSegment(s);
            createHeader(s);
            printHeader((char*)s->header);
            break;
        } else if (strcmp(command, "time") == 0) {
            printf("Receive TIME from server...\n");
            printf("\n");
            bytes = recv(socket_fd, buffer, sizeof(buffer) - 1, 0);
            buffer[bytes] = '\0';
            printf("Time: %s\n", buffer);
            break;
        } else {
            bytes = recv(socket_fd, buffer, sizeof(buffer) - 1, 0);
            buffer[bytes] = '\0';
            printf("server: %s\n", buffer);
        }
    }

}

/*
 * @description
 * 1. Create a socket and connect to server.
 *    (server's IP address = "127.0.0.1")
 *    (server's port number = 45525)
 * 2. Receive message: "Hi, I'm server {Your_student_ID}..." from server and print it out.
 *    (The message you sent from server)
 * 3. Complete the function: receiveData()
*/
int main(int argc, char* argv[]) {
    int socket_fd;
    struct sockaddr_in server_addr;

    // Create TCP socket.
    socket_fd = socket(AF_INET, SOCK_STREAM, 0);

    // Set up server's address.
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");

    // Connect to server's socket.
    connect(socket_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));


    // Receive message: "Hi, I'm server {Your_student_ID}..." from server and print it out.
    char buffer[BUFFER_SIZE];
    int bytes = recv(socket_fd, buffer, sizeof(buffer) - 1, 0);
    
    buffer[bytes] = '\0';  // Null-terminate the string
    printf("server: %s\n", buffer);
    

    Segment s;
    receiveData(socket_fd, &s);

    printf("\nClose socket\n");
    close(socket_fd);
    return 0;
}
