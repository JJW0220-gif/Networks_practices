#include "header.h"
#define PORT 45525
#define BUFFER_SIZE 1024
/*
 * @description
 * In this function, You need to implement the server side
 * that sends messages to and receives messages from the client.
 *
 *         Send the message: "Enter a command (data / time)..."
 * Server -----------------------------------------------------------> Client
 * 
 *         Receive the message: "data" or "time" or {invalid command}
 * Server <----------------------------------------------------------- Client
 * 
 *         data: Read the text file from input and send the segment.
 *         time: Get the current time and send the time string. (format: "2025-01-22 13:14:52")
 *         {invalid command}: Send the message: "Invalid command! Try again! Enter a command (data / time)..."
 * Server -----------------------------------------------------------> Client
 *
 * @param
 * client_fd: The socket file descriptor used for sending/receiving data  
 *            with a client that has connected to server.
 * fileName: The file name read from sample input. e.g. "sample_input.txt"
*/
void serverFunction(int client_fd, char* fileName) {
    char buffer[BUFFER_SIZE];
    Segment seg;
    int bytes;

    FILE* file = fopen(fileName, "r");

    // 傳送提示
    char* prompt = "Enter a command (data / time)...";
    send(client_fd, prompt, strlen(prompt), 0);
    

    while (1) {

        // 接收 client 的輸入
        memset(buffer, 0, sizeof(buffer));
        bytes = recv(client_fd, buffer, sizeof(buffer), 0);
        buffer[bytes] = '\0';

        if (strcmp(buffer, "data") == 0) {
            fseek(file, 0, SEEK_SET);
            readFile(&seg, fileName);
            send(client_fd, &seg, sizeof(Segment), 0);
            break;
        } else if (strcmp(buffer, "time") == 0) {
            char timeBuffer[64];
            time_t now = time(0);
            strftime(timeBuffer, sizeof(timeBuffer), "%F %T", localtime(&now));
            send(client_fd, timeBuffer, strlen(timeBuffer), 0);
            break;
        } else {
            char* msg = "Invalid command! Try again! Enter a command (data / time)...";
            send(client_fd, msg, strlen(msg), 0);
        }
    }

    fclose(file);
}

/*
 * @description
 * 1. Create a TCP socket bind to port 45525.
 * 2. Listen the TCP socket.
 * 3. Accept the connect and get the client socket file descriptor (client_fd).
 * 4. Send message: "Hi, I'm server {Your_student_ID}" to client.
 * 5. Complete the function: serverFunction()
*/
int main(int argc, char* argv[]) {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    int addr_len = sizeof(client_addr);

    // Create TCP socket.
    server_fd = socket(AF_INET, SOCK_STREAM, 0);

    // Set up server's address.
    memset(&server_addr, 0, sizeof(server_addr));       //server_addr初始化為0
    server_addr.sin_family = AF_INET;           // 使用的是IPv4位址格式
    server_addr.sin_addr.s_addr = INADDR_ANY;       // 綁定任意可用 IP
    server_addr.sin_port = htons(PORT);       // 將port轉換為網路位元組序 (big-endian)

    // Bind socket to the address.  
    //把這個 socket 綁定到特定的 IP 位址和 Port 上
    bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr));

    // Listening the socket.
    listen(server_fd, 5);       //server_fd：你要監聽的 socket //5：backlog（可以理解成連線等待佇列的最大數量） 

    
    while(1) {
        // Accept the connect request.
        // client_fd = ...
        client_fd = accept(server_fd, (struct sockaddr*)&client_addr, &addr_len);
        printf("New connection\n");

        // Send message: "Hi, I'm server {Your_student_ID}" to client.
        // Send messages to client.
        char greet[] = "Hi, I'm server 112062117\n";
        send(client_fd, greet, strlen(greet), 0);

        
        usleep(500000);          // optional delay
        serverFunction(client_fd, argv[1]);
        close(client_fd);
    }
    close(server_fd);
    return 0;
}
